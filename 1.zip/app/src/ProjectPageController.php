<?php

namespace SilverStripe\Portfolio;

use PageController;    

class ProjectPageController extends PageController 
{

}