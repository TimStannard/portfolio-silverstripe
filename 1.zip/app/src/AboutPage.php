<?php

namespace SilverStripe\Portfolio;

use Page;
use PageController;

class AboutPage extends Page 
{
}
class AboutPageController extends PageController 
{

}
