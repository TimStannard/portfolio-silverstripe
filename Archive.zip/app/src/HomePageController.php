<?php

namespace SilverStripe\Portfolio;

use PageController;    

class HomePageController extends PageController 
{

}