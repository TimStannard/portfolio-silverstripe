<?php

namespace SilverStripe\Portfolio;

use PageController;    

class ProjectHolderController extends PageController 
{

}