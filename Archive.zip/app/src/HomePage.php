<?php

namespace SilverStripe\Portfolio;

use Page;    

class HomePage extends Page 
{

}